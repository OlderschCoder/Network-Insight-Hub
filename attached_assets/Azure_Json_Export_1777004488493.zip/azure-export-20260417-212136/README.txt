Azure CLI export bundle
Generated: 2026-04-17T21:24:31.0209918-05:00
Machine: LP-LDA116-01
User: mark.bojeun
Output folder: C:\Code\Aruba\azure-export-20260417-212136

Upload this entire folder (zip recommended).

Files are UTF-8. JSON outputs can be opened in a viewer or imported to diagram tools.
MANIFEST.txt lists filenames and byte sizes.
