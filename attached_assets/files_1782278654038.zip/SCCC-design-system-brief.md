# SCCC Portfolio — Design System Brief & Replit Prompts

Drop this in your unified repo. Paste the relevant section into each Replit project.
Goal: every app looks like one studio built it, and "make it professional" changes
the **whole site**, not one page.

---

## 0. Why one page changes instead of the whole site

The agent edits the file that's open. If styling is repeated inline on every page,
there's no shared place to change — so only the open page updates. The fix below is
to centralize tokens + primitive components, then point the agent at *those*.

---

## 1. Shared tokens (same across all 13 apps)

Use this identical palette/type/scale everywhere so the portfolio is cohesive.
Tune the accent per app if you want each to have its own signature, but keep the
neutral scale, spacing, radius, and type identical.

**Color**
- Neutral scale (use for 95% of the UI): a single gray ramp, not pure black.
  - bg `#0B0E14` (dark) / `#FAFAFA` (light)
  - surface `#151A23` / `#FFFFFF`
  - border `#262C38` / `#E6E8EC`
  - text-strong `#F4F6F8` / `#0B0E14`
  - text-muted `#9BA3B0` / `#5A6472`
- Accent — ONE per app (SCCC green works as the house accent): `#16A34A`
  - accent-hover `#15803D`, accent-subtle bg `#16A34A1A`
- Semantic: success `#16A34A`, warning `#D97706`, danger `#DC2626`, info `#2563EB`

**Type**
- One sans for everything: Inter or Geist. Weights: 400 body, 500 labels, 600 headings.
- Scale (px): 12 / 14 / 16 / 20 / 24 / 32 / 40. Line-height 1.5 body, 1.2 headings.
- Tabular numbers for any dashboard figures (`font-variant-numeric: tabular-nums`).

**Spacing** — 4px base: 4 / 8 / 12 / 16 / 24 / 32 / 48 / 64. Card padding 24. Page gutter 32.

**Radius** — sm 6 / md 10 / lg 14. Pick one and stay consistent (md is a safe default).

**Shadow** — keep them quiet:
- `0 1px 2px rgba(0,0,0,.06)` resting
- `0 4px 12px rgba(0,0,0,.08)` raised
- No dark/heavy drop shadows. Prefer a 1px border + faint shadow.

---

## 2. Tailwind starter (most Replit React apps)

`tailwind.config.js` → extend theme with the tokens, then drive colors from CSS vars
so you can theme without touching markup:

```js
// tailwind.config.js
export default {
  theme: {
    extend: {
      colors: {
        bg: 'rgb(var(--bg) / <alpha-value>)',
        surface: 'rgb(var(--surface) / <alpha-value>)',
        border: 'rgb(var(--border) / <alpha-value>)',
        strong: 'rgb(var(--text-strong) / <alpha-value>)',
        muted: 'rgb(var(--text-muted) / <alpha-value>)',
        accent: 'rgb(var(--accent) / <alpha-value>)',
      },
      borderRadius: { md: '10px', lg: '14px' },
      fontFamily: { sans: ['Inter', 'system-ui', 'sans-serif'] },
    },
  },
};
```

```css
/* globals.css */
:root {
  --bg: 11 14 20; --surface: 21 26 35; --border: 38 44 56;
  --text-strong: 244 246 248; --text-muted: 155 163 176; --accent: 22 163 74;
}
.light {
  --bg: 250 250 250; --surface: 255 255 255; --border: 230 232 236;
  --text-strong: 11 14 20; --text-muted: 90 100 114; --accent: 22 163 74;
}
body { @apply bg-bg text-strong font-sans antialiased; }
```

Now `bg-surface`, `border-border`, `text-muted`, `text-accent` work everywhere, and
the whole app re-themes by editing six variables.

---

## 3. Primitive components to centralize

Build these once; every page imports them. This is what makes a single agent edit
ripple across the site:

- `AppShell` (nav + content frame) — every page renders inside it
- `PageHeader` (title + subtitle + actions)
- `Card`
- `Button` (variants: primary / secondary / ghost / danger)
- `Input`, `Select`, `Label`
- `Table` (consistent header, row hover, padding)
- `Badge` / `StatusPill` (your Active / In Progress / Unknown tags)
- `Stat` (the dashboard metric tile)

> If the app already uses shadcn/ui, you're most of the way there — just standardize
> the tokens above and stop hand-styling one-off components.

---

## 4. The prompts to paste into Replit (in order)

**Pass 1 — build the system, touch nothing else**
> Create a centralized design system. Add the design tokens (color, typography,
> spacing, radius, shadow) from this brief to tailwind.config.js and globals.css using
> CSS variables. Then build reusable primitives: AppShell, PageHeader, Card, Button,
> Input, Select, Table, Badge/StatusPill, and Stat. Do NOT modify any existing pages
> yet. Show me the components in isolation first.

**Pass 2 — migrate in small batches**
> Refactor [Dashboard, Settings, Reports] to use the new shared components and tokens.
> Replace inline/per-page styling with the primitives. Apply this across every element
> on these routes, not just the top of the page. Change ONLY styling and layout —
> preserve all logic, data, and behavior exactly.

Repeat Pass 2 three pages at a time until every route is migrated.

**Pass 3 — global polish**
> Now do one consistency pass across the entire app: uniform card padding (24px),
> consistent spacing scale, one accent color used sparingly, hairline borders with
> subtle shadows (no heavy dark shadows), tabular numbers on all dashboard figures,
> and a clear type hierarchy. Keep one signature element per app; keep everything
> else quiet. Verify mobile down to 360px and visible keyboard focus.

**Guardrail to include in every prompt**
> Change styling only. Do not alter routes, state, API calls, or behavior. If a change
> would affect functionality, stop and ask.

---

## 5. The "dated" checklist — what to remove

- Gradients on everything → gradient only on the hero, if at all
- Heavy/dark drop shadows → 1px border + faint shadow
- Beveled / glossy buttons → flat, one accent, clear hover
- Saturated colored borders → neutral hairline borders
- Cramped spacing → 4/8px scale, more whitespace
- Default Bootstrap type → Inter/Geist with real hierarchy
- Five accent colors → one accent + neutral gray ramp

---

## 6. Cross-app consistency (the portfolio view)

Keep Section 1 identical in all 13 apps. Vary only the accent if you want each app to
have its own identity. Because they share the token names and primitive components,
your Project Hub will read as one coherent product family instead of 13 separate
experiments. Consider committing `globals.css` + the primitives as a small shared
snippet in your unified repo so each new project starts from the same baseline.
